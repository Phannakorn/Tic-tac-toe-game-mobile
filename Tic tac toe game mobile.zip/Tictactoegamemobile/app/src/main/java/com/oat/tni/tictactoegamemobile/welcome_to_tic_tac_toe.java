package com.oat.tni.tictactoegamemobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class welcome_to_tic_tac_toe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_to_tic_tac_toe);
    }
}