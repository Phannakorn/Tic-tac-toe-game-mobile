package com.oat.tni.game_tic_tac_toe;

import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.net.CookieHandler;
import java.util.Random;


public  class  SimpleAsyncTaskreplay4_4  extends AsyncTask<Void, Integer, String> {
    private WeakReference<Grid4_4> main;
    SimpleAsyncTaskreplay4_4(Grid4_4 tv) { main = new WeakReference<>(tv);
    }

    @Override
    protected String doInBackground(Void... voids) {

        for (int i=0 ; i<16 ; i++) {
            try {
                Thread.sleep(300);
                if ( main.get().replay[i] == 0)
                    return "";
                publishProgress(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Log.d("HERE","Hiiiiiiiiiiiiiiiiiiiiiiii");
        return "";
    }
    @Override
    protected void onProgressUpdate(Integer... i) {
        super.onProgressUpdate(i);
        main.get().gameProcess(main.get().replay[i[0]]);
    }

}