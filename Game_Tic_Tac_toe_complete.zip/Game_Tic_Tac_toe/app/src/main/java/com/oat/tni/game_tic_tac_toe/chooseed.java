package com.oat.tni.game_tic_tac_toe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class chooseed extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chooseed);
    }

    public void Togrid3_3(View view) {
        Intent Grid3 = new Intent(this,Grid3_3.class);
        startActivity(Grid3);
    }

    public void Togrid4_4(View view) {
        Intent Grid4 = new Intent(this,Grid4_4.class);
        startActivity(Grid4);
    }

    public void Togrid5_5(View view) {
        Intent Grid5 = new Intent(this,Grid5_5.class);
        startActivity(Grid5);
    }
}