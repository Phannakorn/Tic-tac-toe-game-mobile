package com.oat.tni.game_tic_tac_toe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.security.PublicKey;

public class Grid5_5 extends AppCompatActivity implements View.OnClickListener {
    private Button[][] buttons = new Button[5][5];

    private  boolean player1turn = true;
    private  int roundCount;
    private TextView textViewPlayer1;
    private TextView textViewPlayer2;
    public  int replay[] = new  int[25];
    private int index = 0;
    private int sum =0;
    private  int X=1;
    private  int Y=-1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid5_5);

        textViewPlayer1 = findViewById(R.id.text_player1);
        textViewPlayer2 = findViewById(R.id.text_player2);

        for (int i = 0 ; i<5 ; i++){
            for(int j=0; j<5 ; j++){
                String buttonID = "button_" + i + j ;
                int resID = getResources().getIdentifier(buttonID,"id",getPackageName());
                buttons[i][j]= findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }
        Button buttonReplay = findViewById(R.id.button_replay);
        buttonReplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetBoard();
                Replay();
            }
        });

        Button buttonReset = findViewById(R.id.button_playagain);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i=0;i<25;i++){
                    replay[i] = 0;
                }
                resetBoard();
                Eablebutton();
            }
        });
    }



    @Override
    public void onClick(View v) {
        replay[index++] = v.getId();
        gameProcess(v.getId());

    }
    private  void Replay(){

        new SimpleAsyncTaskreplay5_5(this).execute();
    }
    public   void gameProcess(int id){
        View v = findViewById(id);

        if (!((Button)v).getText().toString().equals("")){
            return;
        }
        if (player1turn){
            ((Button)v).setText("X");
            ((Button)v).setEnabled(false);
            ((Button)v).setTextColor(getResources().getColor(R.color.red));
        } else {
            ((Button)v).setText("O");
            ((Button)v).setEnabled(false);
            ((Button)v).setTextColor(getResources().getColor(R.color.blue));

        }
        roundCount++;

        if(checkForwin()){
            if(player1turn){
                player1Win();
            }else {
                player2Win();
            }
        } else if (roundCount == 25) {
            draw();
        }else {
            player1turn = !player1turn;
        }
    }
    private  boolean checkForwin(){
        String[][] field = new String[5][5];
        for (int i = 0 ; i < 5 ; i++){
            for (int j =0 ;j <5;j++){
                field[i][j] = buttons[i][j].getText().toString();
            }
        }
        for(int i = 0 ; i <5 ; i++) {
            sum = 0;
            for (int j =0 ;j <5;j++) {
                if (field[i][j].equals("X")) {
                    sum += 1;
                }
                if (field[i][j].equals("O")) {
                    sum += -1;
                }
                if (field[i][j].equals("")){
                    sum = 0;
                }
                if (sum == 3 || sum == -3) {
                    return true;
                }
            }
        }

        for(int j = 0 ; j <5 ; j++) {
            sum = 0;
            for (int i =0 ;i <5;i++) {
                if (field[i][j].equals("X")) {
                    sum += 1;
                }
                if (field[i][j].equals("O")) {
                    sum += -1;
                }
                if (field[i][j].equals("")){
                    sum = 0;
                }
                if (sum == 3 || sum == -3) {
                    return true;
                }
            }
        }

        for(int i= 0; i<5 ; i++) {
            for (int j= 0; j<3 ; j++) {
                sum = 0;
                for (int k=0 ; k<5 ; k++) {
                    if(i+k>4 || j+k>4){
                        break;
                    }
                    if (field[i+k][j+k].equals("X")) {
                        sum += 1;
                    }
                    if (field[i+k][j+k].equals("O")) {
                        sum += -1;
                    }
                    if (field[i+k][j+k].equals("")){
                        sum = 0;
                    }
                    if (sum == 3 || sum == -3) {
                        return true;
                    }
                }
            }
        }

        for(int i= 4; i>=0 ; i--) {
            for (int j= 0; j<3 ; j++) {
                sum = 0;
                for (int k=0 ; k<5 ; k++) {
                    if(i-k<0 || j+k>4){
                        break;
                    }
                    if (field[i-k][j+k].equals("X")) {
                        sum += 1;
                    }
                    if (field[i-k][j+k].equals("O")) {
                        sum += -1;
                    }
                    if (field[i-k][j+k].equals("")){
                        sum = 0;
                    }
                    if (sum == 3 || sum == -3) {
                        return true;
                    }
                }
            }
        }
        return  false;
    }

    private  void  player1Win() {
        Toast.makeText(this, "Player 1 win", Toast.LENGTH_SHORT).show();
        updatePointText1();
        disablebutton();
    }
    private  void  player2Win() {
        Toast.makeText(this, "Player 2 win", Toast.LENGTH_SHORT).show();
        updatePointText2();
        disablebutton();
    }
    private  void  draw() {
        textViewPlayer1.setText("Player1:Draw");
        textViewPlayer2.setText("Player2:Draw");
        Toast.makeText(this, "Draw", Toast.LENGTH_LONG).show();
        disablebutton();
    }
    private void updatePointText1(){
        textViewPlayer1.setText("Player1:WIN");
    }
    private void updatePointText2(){
        textViewPlayer2.setText("Player2:WIN");
    }

    private void  resetBoard(){
        for (int i = 0; i<5 ; i++) {
            for (int j=0; j<5; j++){
                buttons[i][j].setText("");
            }
        }
        textViewPlayer1.setText("Player1: 0");
        textViewPlayer2.setText("Player2: 0");
        roundCount = 0;
        index = 0;
        sum = 0;
        player1turn = true;
    }
    private  void disablebutton(){
        for (int i = 0 ; i<5 ; i++){
            for(int j=0; j<5 ; j++){
                String buttonID = "button_" + i + j ;
                int resID = getResources().getIdentifier(buttonID,"id",getPackageName());
                buttons[i][j]= findViewById(resID);
                buttons[i][j].setEnabled(false);
            }
        }
    }
    private  void Eablebutton(){
        for (int i = 0 ; i<5 ; i++){
            for(int j=0; j<5 ; j++){
                String buttonID = "button_" + i + j ;
                int resID = getResources().getIdentifier(buttonID,"id",getPackageName());
                buttons[i][j]= findViewById(resID);
                buttons[i][j].setEnabled(true);
            }
        }
    }
}